# Proof-of-knowledge-base-code-
The P.o.K part That Morrison was talking about was already done(yaaay) soo im just going to drop this here and you guys can build off of it or edit ,contribute to it. Feel free todo what ever you guys want😆✌, just a code placeholder as well. we dont have to use this if everyone dosent agree but, it here
